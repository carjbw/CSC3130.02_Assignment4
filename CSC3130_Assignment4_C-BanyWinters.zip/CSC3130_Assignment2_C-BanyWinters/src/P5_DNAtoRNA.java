public class P5_DNAtoRNA {
    public String transcribeRNA(String DNA) {
        String RNA = "";
        for(int i = 0; i < DNA.length(); i++) {
            if(DNA.charAt(i) == 'T') {
                RNA += 'U';
            }
            else {
                RNA += DNA.charAt(i);
            }
        }
        return RNA;
    }
}
