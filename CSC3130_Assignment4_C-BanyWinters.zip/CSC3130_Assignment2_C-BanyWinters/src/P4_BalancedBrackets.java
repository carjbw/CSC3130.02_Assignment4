import java.util.Stack;

public class P4_BalancedBrackets {
    /*
    {[()]} YES
    {[(])} NO
    {{[[(())]]}} YES
    Given a String input s composed of brackets, determine whether s is balanced.
    @param String s : a series of brackets
    @return String : "YES" if s is balanced, "NO" if s in unbalanced
     */
    public String isBalanced(String s) {
        // vLn [OD] define matching pairs of brackets {open, close}
        char[][] pairs = {
                {'[', ']'},
                {'{', '}'},
                {'(', ')'}
        };
        // ^Ln [AA] Asmt. = O(1)
        // vLn [OD] create a stack to keep track of opens in s
        Stack<Character> opens = new Stack<>(); // <Ln [AA] Asmt. = O(1)
        // vLn [OD] itr. thru chars in s
        for(int i = 0; i < s.length(); i++) {
            // ^Ln [AA] LInit. Asmt. + Comp. + Accs. + Arth. = O(1)
            // vLn [OD] b = char is s we are currently interested in
            char b = s.charAt(i); // <Ln [AA] Asmt. + Accs. = O(1)
            if( isOpen(b, pairs) ) {
                // vLn [OD] IWGH, b is an open -> push b to top of opens Stack
                opens.push(b);
            }
            else if(
                    opens.isEmpty() ||
                    !isMatching(opens.pop(), b, pairs)
            ) {
                /*
                [OD] IWGH, b is a close...
                    (a) opens is empty -> first bracket was a close -> UNBALANCED
                    (b) b does NOT match most recent close pushed to opens Stack -> UNBALANCED
                 */
                return "NO";
            }
        }
        if( opens.isEmpty() ) {
            // [OD] IWGH, all opens have been matched to a close -> BALANCED
            return "YES";
        }
        // [OD] IWGH, there is an open that was not matched -> UNBALANCED
        return "NO";
    }
    private boolean isOpen(char b, char[][] pairs) {
        for(char[] p : pairs) {
            if(p[0] == b) {
                return true;
            }
        }
        return false;
    }
    private boolean isMatching(char open, char close, char[][] pairs) {
        for(char[] p : pairs) {
            if( (open == p[0]) && (close == p[1]) ) {
                return true;
            }
        }
        return false;
    }
}
