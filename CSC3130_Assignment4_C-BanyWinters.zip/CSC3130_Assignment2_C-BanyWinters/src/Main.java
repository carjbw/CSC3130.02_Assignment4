
public class Main {
    public static void main(String[] args) {
        int P = 6; // <- SELECT PROBLEM HERE
        new Main().setInput(P);
    }
    private void setInput(int P) {
        String[] input = {""}; String title = "";
        switch(P) {
            // PROBLEM 4 | BALANCED BRACKETS
            case 4 -> {
                input = new String[]{
                        // EDIT PROBLEM 4 INPUT VALUES HERE
                        "{[()]}",
                        "{[(])}",
                        "{{[[(())]]}}",
                };
                title = "BALANCED BRACKETS";
            }
            // PROBLEM 5 | DNA TO RNA
            case 5 -> {
                input = new String[]{
                        // EDIT PROBLEM 5 INPUT VALUES HERE
                        "AGCTGGGAAACGTAGGCCTA",
                        "TTTTTTTTTTGGCGCG",
                        "CTTTGGGACTAGTAACCCATTTCGGCT"
                };
                title = "DNA TO RNA";
            }
            case 6 -> {
                input = new String[]{
                        "AGCUGGGAAACGUAGGCCUA",
                        "UAAAGAGAAGCCAGC"
                };
                title = "RNA TO PROTEINS";
            }
        }
        test(P, title, input);
    }
    private void test(int P, String title, String[] input) {
        System.out.println("PROBLEM " + P + " | " + title);
        for(int i = 0; i < input.length; i++) {
            if(input.length > 1) {
                System.out.println("Case " + (i+1) + ": ");
            }
            String inputStr = "Input: ";
            String outputStr = "Output: ";
            switch(P) {
                case 4 -> {
                    inputStr += input[i];
                    P4_BalancedBrackets P4 = new P4_BalancedBrackets();
                    outputStr += P4.isBalanced(input[i]);
                }
                case 5 -> {
                    inputStr += input[i];
                    P5_DNAtoRNA P5 = new P5_DNAtoRNA();
                    outputStr += P5.transcribeRNA(input[i]);
                }
                case 6 -> {
                    inputStr += input[i];
                    P6_RNAtoProtiens P6 = new P6_RNAtoProtiens();
                    outputStr += P6.getProtiens(input[i]);
                }
            }
            System.out.println(inputStr);
            System.out.println(outputStr);
            System.out.println();
        }
    }
}