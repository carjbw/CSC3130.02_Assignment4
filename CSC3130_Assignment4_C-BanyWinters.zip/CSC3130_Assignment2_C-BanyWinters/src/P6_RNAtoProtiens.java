import java.util.ArrayDeque;
import java.util.Stack;
import java.util.Arrays;
public class P6_RNAtoProtiens {

    Stack<String> codons;
    public String getProtiens(String RNA) {
        Stack<Character> sequenceChars = new Stack<>();
        Stack<String> codons = getCodons(RNA);
        for(String c : codons) {
            sequenceChars.push(getProtien(c));
        }
        String sequence = "";
        for(Character c : sequenceChars) {
            sequence += sequenceChars.pop();
        }
        this.codons = codons;
        return RNA;
    }

    private Stack<String> getCodons(String RNA) {
        Stack<String> codons = new Stack<>();
        String newCodon = ""; int j = 0;
        for(int i = 0; i < (RNA.length()); i++) {
            newCodon += RNA.charAt(i);
            j++;
            if(j >= 3 || i == (RNA.length() - 1)) {
                codons.push(newCodon);
                newCodon = "";
                j = 0;
            }
        }
        return codons;
    }
    private Character getProtien(String codon) {
        char[] protiens = {
                'F', 'L', 'S', 'Y', '.', 'C', 'W',
                'P', 'H', 'Q', 'R', 'I', 'M', 'T',
                'N', 'K', 'V', 'A', 'D', 'E', 'G'};
        int i = switch(codon) {
            case "UUU", "UUC" -> 0; // F
            case "UUA", "UUG", "CUU", "CUC", "CUA", "CUG" -> 1; // L
            case "UCU", "UCC", "UCA", "UCG", "AGU", "AGC" -> 2; // S
            case "UAU", "UAC" -> 3; // Y
            case "UAA", "UAG", "UGA" -> 4; // .
            case "UGU", "UGC" -> 5; // C
            case "UGG" -> 6; // W
            case "CCU", "CCC", "CCA", "CCG" -> 7; // P
            case "CAU", "CAC" -> 8; // H
            case "CAA", "CAG" -> 9; // Q
            case "CGU", "CGC", "CGA", "CGG", "AGA", "AGG" -> 10; // R
            case "AUU", "AUC", "AUA" -> 11; // I
            case "AUG" -> 12; // M
            case "ACU", "ACC", "ACA", "ACG" -> 13; // T
            case "AAU", "AAC" -> 14; // N
            case "AAA", "AAG" -> 15; // K
            case "GUU", "GUC", "GUA", "GUG" -> 16; // V
            case "GCU", "GCC", "GCA", "GCG" -> 17; // A
            case "GAU", "GAC" -> 18; // D
            case "GAA", "GAG" -> 19; // E
            case "GGU", "GGC", "GGA", "GGG" -> 20; // G
            default -> 0;
        };
        return protiens[i];
    }

    public static void main(String[] args) {
        P6_RNAtoProtiens P6 = new P6_RNAtoProtiens();
        System.out.println(P6.getProtiens("AGCUGGGAAACGUAGGCCUA"));
    }
}
